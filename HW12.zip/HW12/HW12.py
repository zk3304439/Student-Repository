"""
Author:Yiyang Shi
HW12:flask
Show the table by html and flask
"""

from flask import Flask, render_template
import sqlite3
from typing import Dict

DB_FILE: str = "810_startup.db"

app: Flask = Flask(__name__)


@app.route('/hw12')
def hw12() -> str:
    query = """select e.name, e.CWID, g.Course, g.Grade, i.Name
                              from students e
                                join grades g on e.CWID=g.StudentCWID
                                join instructors i on g.InstructorCWID = i.CWID
                              order by e.name"""

    db: sqlite3.Connection = sqlite3.connect(DB_FILE)

    """pass the data to template"""
    data: Dict[str, str] = \
        [{'name': name, 'cwid': CWID, 'course': Course, 'grade': Grade, 'ins': Name}
           for name, CWID, Course, Grade, Name in db.execute(query)]

    db.close()

    return render_template('parameters.html',
                           title='Stevens Repository',
                           table_title="Student, Course, Grade, and Instructor",
                           students=data)


app.run(debug=True)
